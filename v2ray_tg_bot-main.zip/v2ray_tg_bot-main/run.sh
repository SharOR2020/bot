#!/bin/bash

source "/home/python/venv/bin/activate";
cd "/home/python/";
python3 bot.py;
echo "Bot has been stopped! Check the logs ...";
